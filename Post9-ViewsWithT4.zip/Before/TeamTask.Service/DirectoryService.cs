﻿//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Channels;
using System.ServiceModel.Syndication;
using System.ServiceModel.Web;
using TeamTask.Model;

namespace TeamTask.Service
{
    [ServiceContract]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class DirectoryService
    {
        public const string Route = "";

        private static readonly List<ResourceCollection> resourceCollections =  
            new List<ResourceCollection>() { 
                new ResourceCollection()  
                { 
                    Route = TaskService.Route, 
                    Name = "Tasks Collection", 
                    Description = "A collection of the current tasks for the team.",   
                }, 
                new ResourceCollection() 
                { 
                    Route = UserService.Route,  
                    Name = "Users Collection",  
                    Description = "A collection of the current users on the team.",  
                }  
            };

        [WebGet(UriTemplate = "")]
        public Message GetDirectory()
        {
            WebOperationContext context = WebOperationContext.Current;
            IncomingWebRequestContext request = context.IncomingRequest;

            foreach (ContentType acceptElement in request.GetAcceptHeaderElements())
            {
                switch (acceptElement.MediaType.ToUpperInvariant())
                {
                    case "APPLICATION/XML":
                    case "TEXT/XML":
                        return context.CreateXmlResponse(resourceCollections);
                    case "APPLICATION/JSON":
                        return context.CreateJsonResponse(resourceCollections);
                    case "APPLICATION/ATOM+XML":
                        SyndicationFeed feed = GetAtomFeed();
                        return context.CreateAtom10Response(feed);
                }
            }

            return context.CreateXmlResponse(resourceCollections);
        }

        private static SyndicationFeed GetAtomFeed()
        {
            DateTime itemDate = DateTime.Now;
            string feedTitle = "Team Task Resources";
            string feedDescription = "The Resource Collections of the Team Task Service.";
            Uri feedUri = new Uri(DirectoryService.Route, UriKind.Relative);

            var items = resourceCollections.Select(resource =>
                new SyndicationItem(resource.Name, resource.Description,
                    resource.Uri, "tag:???", itemDate));

            return new SyndicationFeed(feedTitle, feedDescription, feedUri, items);
        }
    }
}

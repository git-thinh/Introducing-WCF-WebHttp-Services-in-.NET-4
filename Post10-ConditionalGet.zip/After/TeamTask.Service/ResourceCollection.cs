﻿//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TeamTask.Service
{
    public class ResourceCollection
    {
        internal string Route { get; set; }     
        public string Name { get; set; }
        public string Description { get; set; }

        public Uri Uri
        {
            get
            {
                return new Uri(this.Route, UriKind.Relative);
            }
            set { }
        }

        public Uri HelpUri
        {
            get
            {
                return new Uri(this.Route + "/help", UriKind.Relative);
            }
            set { }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TeamTask.Service
{
    public static class Extensions
    {
        public static string ToHexString(this byte[] byteArray)
        {
            return string.Join(string.Empty, byteArray.Select(b => b.ToString("X")));
        }
    } 

}
﻿//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Xml.Linq;
using Microsoft.Http;
using TeamTask.Model;
using Microsoft.Http.Headers;
using System.Net;

namespace TeamTask.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            using (HttpClient client = new HttpClient("http://localhost:8080/TeamTask/"))  
            {
                EntityTag etag = null;
                
                // Get the task and the etag
                Task task = GetTask(client, 2, ref etag);

                // Get the task a second time and include the etag
                GetTask(client, 2, ref etag);

                // Update the task;
                task.Status = (task.Status == TaskStatus.Completed) ?
                    TaskStatus.InProgress :
                    TaskStatus.Completed;
                UpdateTask(client, task);

                // Get the task again... the etag should be stale
                GetTask(client, 2, ref etag);

                Console.ReadKey();
             }
        }

        static void GetResourceCollections(HttpClient client, string acceptType)
        {
            Console.WriteLine("Getting the resource collections as '{0}':", acceptType);
            using (HttpRequestMessage request = new HttpRequestMessage("GET", string.Empty))
            {
                request.Headers.Accept.AddString(acceptType);
                using (HttpResponseMessage response = client.Send(request))
                {
                    response.EnsureStatusIsSuccessful();
                    if (response.Content.ContentType.Contains("xml"))
                    {
                        Console.WriteLine(response.Content.ReadAsXElement().ToString());
                    }
                    else
                    {
                        Console.WriteLine(response.Content.ReadAsString());
                    }
                }
            }
            Console.WriteLine();
        }

        static void WriteOutTask(Task task)
        {
            Console.WriteLine("  Id:      {0}", task.Id);
            Console.WriteLine("  Title:   {0}", task.Title);
            Console.WriteLine("  Status:  {0}", task.Status);
            Console.WriteLine("  Created: {0}", task.CreatedOn.ToShortDateString());
            Console.WriteLine();
        }

        static void GetUser(HttpClient client, string userName, string accepts)
        {
            Console.WriteLine("Getting user '{0}':", userName);
            using (HttpRequestMessage request = new HttpRequestMessage("GET", "Users/" + userName))
            {
                request.Headers.Accept.AddString(accepts);
                using (HttpResponseMessage response = client.Send(request))
                {
                    Console.WriteLine("  Cache-Control: {0}", response.Headers.CacheControl);
                    Console.WriteLine("  Status Code: {0}", response.StatusCode);
                    Console.WriteLine("  Content: {0}", response.Content.ReadAsString());
                }
            }
            Console.WriteLine();
        }

        static Task GetTask(HttpClient client, int id, ref EntityTag etag)
        {
            Console.WriteLine("Getting task '{0}':", id);
            using (HttpRequestMessage request = new HttpRequestMessage("GET", "Tasks/" + id))
            {
                request.Headers.Accept.AddString("application/json");
                if (etag != null)
                {
                    request.Headers.IfNoneMatch.Add(etag);
                }
                using (HttpResponseMessage response = client.Send(request))
                {                
                    if (response.StatusCode == HttpStatusCode.NotModified)
                    {
                        Console.WriteLine("The task with id '{0}' has not been modified.", id);
                        Console.WriteLine();
                        return null;
                    }
                    else
                    {
                        etag = response.Headers.ETag;
                        response.EnsureStatusIsSuccessful();
                        Console.WriteLine("Etag: {0}", etag.Tag);
                        WriteOutContent(response.Content);
                        return response.Content.ReadAsJsonDataContract<Task>();
                    }
                }
            }
        }

        static Task UpdateTask(HttpClient client, Task task)
        {
            Console.WriteLine("Updating task '{0}':", task.Id);
            Console.WriteLine();

            string updateUri = "Tasks/" + task.Id.ToString();
            HttpContent content = HttpContentExtensions.CreateJsonDataContract(task);
            Console.WriteLine("Request:");
            WriteOutContent(content);

            using (HttpResponseMessage response = client.Put(updateUri, content))
            {
                response.EnsureStatusIsSuccessful();
                Console.WriteLine("Response:");
                WriteOutContent(response.Content);
                return response.Content.ReadAsJsonDataContract<Task>();              
            }
        }

        static void WriteOutContent(HttpContent content)
        {
            content.LoadIntoBuffer();
            Console.WriteLine(content.ReadAsString());
            Console.WriteLine();
        }
    }
}
